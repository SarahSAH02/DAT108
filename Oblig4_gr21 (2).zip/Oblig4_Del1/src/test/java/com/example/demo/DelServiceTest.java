package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;

public class DelServiceTest {

    private DelService service;

    @BeforeEach
    void setUp() {
        service = new DelService();
    }

    @Test
    void testValidDeltager() {
        Deltager deltager = new Deltager();
        deltager.setFornavn("Elena");
        deltager.setEtternavn("Jacobsen");
        deltager.setMobil("48391123");
        deltager.setPassord("passord123");
        deltager.setRepetertPassord("passord123");
        deltager.setKjonn("Kvinne");
        BindingResult bindingResult = new BeanPropertyBindingResult(deltager, "deltager");

        boolean result = service.addDeltager(deltager, bindingResult);

        assertTrue(result);
        assertFalse(bindingResult.hasErrors());
    }

    @Test
    void testInvalidFornavnLitenForbokstav() {
        Deltager deltager = new Deltager();
        deltager.setFornavn("ola");
        deltager.setEtternavn("Nordmann");
        deltager.setMobil("12345678");
        deltager.setPassord("hemmelig");
        deltager.setRepetertPassord("hemmelig");
        deltager.setKjonn("Mann");
        BindingResult bindingResult = new BeanPropertyBindingResult(deltager, "deltager");

        boolean result = service.addDeltager(deltager, bindingResult);

        assertFalse(result);
        assertTrue(bindingResult.hasFieldErrors("fornavn"));
    }

    @Test
    void testMobilAlleredeRegistrert() {
        Deltager deltager1 = new Deltager();
        deltager1.setFornavn("Ola");
        deltager1.setEtternavn("Myking");
        deltager1.setMobil("65465654");
        deltager1.setPassord("hemmeli12");
        deltager1.setRepetertPassord("hemmeli12");
        deltager1.setKjonn("Mann");
        BindingResult bindingResult1 = new BeanPropertyBindingResult(deltager1, "deltager");

        boolean result1 = service.addDeltager(deltager1, bindingResult1);
        assertTrue(result1);

        Deltager deltager2 = new Deltager();
        deltager2.setFornavn("Kari");
        deltager2.setEtternavn("Nordmann");
        deltager2.setMobil("65465654");
        deltager2.setPassord("hemmelig123");
        deltager2.setRepetertPassord("hemmelig123");
        deltager2.setKjonn("Kvinne");
        BindingResult bindingResult2 = new BeanPropertyBindingResult(deltager2, "deltager");

        boolean result2 = service.addDeltager(deltager2, bindingResult2);

        assertFalse(result2);
        assertTrue(bindingResult2.hasFieldErrors("mobil"));
    }

    @Test
    void testForKortMobilNr() {
        Deltager deltager = new Deltager();
        deltager.setFornavn("Sarah");
        deltager.setEtternavn("Ahsan");
        deltager.setMobil("12345");
        deltager.setPassord("Sarah1234!");
        deltager.setRepetertPassord("Sarah1234!");
        deltager.setKjonn("Kvinne");
        BindingResult bindingResult = new BeanPropertyBindingResult(deltager, "deltager");

        boolean result = service.addDeltager(deltager, bindingResult);

        assertFalse(result);
        assertTrue(bindingResult.hasFieldErrors("mobil"));
    }

    @Test
    void testForLangtMobilNr() {
        Deltager deltager = new Deltager();
        deltager.setFornavn("Sarah");
        deltager.setEtternavn("Ahsan");
        deltager.setMobil("123456789");
        deltager.setPassord("Sarah1234!");
        deltager.setRepetertPassord("Sarah1234!");
        deltager.setKjonn("Kvinne");
        BindingResult bindingResult = new BeanPropertyBindingResult(deltager, "deltager");

        boolean result = service.addDeltager(deltager, bindingResult);

        assertFalse(result);
        assertTrue(bindingResult.hasFieldErrors("mobil"));
    }

    @Test
    void testPassordMismatch() {
        Deltager deltager = new Deltager();
        deltager.setFornavn("Sarah");
        deltager.setEtternavn("Ahsan");
        deltager.setMobil("12345678");
        deltager.setPassord("kommode");
        deltager.setRepetertPassord("ikkeKommode");
        deltager.setKjonn("Kvinne");
        BindingResult bindingResult = new BeanPropertyBindingResult(deltager, "deltager");

        boolean result = service.addDeltager(deltager, bindingResult);

        assertFalse(result);
        assertTrue(bindingResult.hasFieldErrors("repetertPassord"));
    }
}