public class validerPassord {
	var passord = document.getElementsByName("passord")[0].value;
    var repetertPassord = document.getElementsByName("repetertPassord")[0].value;
    if (passord !== repetertPassord) {
        alert("Passordene er ikke like.");
        return false;
    }
    return true;
}